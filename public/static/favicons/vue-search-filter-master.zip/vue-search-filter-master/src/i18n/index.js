import de from './de.json'
import en from './en.json'

export default {
  de,
  en
}
